"""
The live CRISP loop, one module per stage, matching the proposal's
four-stage design:

    profile.py    -- Trait Profile Specification (loads the target vector)
    generator.py  -- Response Generator
    evaluator.py  -- Trait Evaluator
    refiner.py    -- Response Refiner (reward-based adaptive search)
    orchestrator.py -- CrispSession, ties every stage together and
                        carries conversation history across turns
"""

from .orchestrator import CrispSession

__all__ = ["CrispSession"]
